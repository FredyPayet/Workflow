# Atelier Workflows

Application pour décrire les process de l'entreprise : tâches, sous-étapes, notes, délais et enchaînements (simple, au choix OU, en parallèle ET).

## Installation (une seule fois)

1. Installez Python 3.10 ou plus récent : https://www.python.org/downloads/ (sous Windows, cochez « Add Python to PATH »).
2. Ouvrez un terminal dans ce dossier, puis tapez :

```
pip install -r requirements.txt
```

3. **Facultatif, pour avoir le schéma dans le PDF** : installez le logiciel Graphviz (https://graphviz.org/download/). Sous Windows, cochez « Add Graphviz to the system PATH » pendant l'installation. Sans Graphviz, l'application fonctionne normalement : seul le schéma manque dans le PDF.

## Lancement

```
streamlit run app.py
```

L'application s'ouvre dans votre navigateur. Pour l'arrêter : fermez le terminal (ou Ctrl + C).

## Où sont mes données ?

- Chaque workflow est enregistré automatiquement dans le dossier `workflows/` (un fichier `.json` par workflow).
- Un workflow supprimé va dans `workflows/corbeille/` : vous pouvez le restaurer depuis le menu de gauche.
- **Sauvegarde conseillée** : exportez régulièrement vos workflows en JSON (bouton « Exporter en JSON ») ou copiez le dossier `workflows/`.

## Reprendre un workflow

Menu de gauche → « Importer un workflow » → choisissez le fichier `.json` exporté. Si le workflow existe déjà, l'application vous demande s'il faut le remplacer ou garder les deux.

## Contenu du dossier

| Fichier | Rôle |
|---|---|
| `app.py` | L'application (code commenté en français) |
| `requirements.txt` | Les bibliothèques à installer |
| `.streamlit/config.toml` | Les couleurs de l'application |
| `exemples/exemple_reception_lot.json` | Un workflow d'exemple à importer |
